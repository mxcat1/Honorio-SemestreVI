create procedure compras_prove(IN fecha varchar(100))
  begin
    select M.Fecha,M.Razon_Social,M.Tipo_Movimiento,sum(DM.Cantidad_Producto*DM.Precio_Unitario) Total from movimientos M
          inner join detalle_movimientos DM
                on M.Codigo_Movimiento=DM.Codigo_Movimiento
          inner join productos P
                on P.Codigo_Producto=DM.Codigo_Producto where M.Tipo_Movimiento='Compra' and M.Fecha like concat(fecha,'%')
    group by M.Fecha,M.Razon_Social;
  end;

