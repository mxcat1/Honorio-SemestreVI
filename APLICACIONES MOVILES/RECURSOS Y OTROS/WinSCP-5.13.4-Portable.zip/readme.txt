This is the README file for standalone package of WinSCP for portable use.

For portable use of WinSCP see
https://winscp.net/eng/docs/portable

The package includes two executables, .exe and .com. For details see
https://winscp.net/eng/docs/executables

WinSCP homepage is https://winscp.net/

See the file 'license.txt' for the license conditions.
