create procedure det_bol_fac(IN nro_co int, IN usu varchar(255))
  begin
    select M.Numero_Comprobante,M.Razon_Social,P.Descripcion_Producto,DM.Cantidad_Producto,(DM.Cantidad_Producto*DM.Precio_Unitario)Monto from movimientos M
           inner join detalle_movimientos DM
                 on M.Codigo_Movimiento=DM.Codigo_Movimiento
           inner join productos P
                 on P.Codigo_Producto=DM.Codigo_Producto
    where M.Numero_Comprobante=nro_co and M.Razon_Social=usu;
  end;

