
CREATE PROCEDURE [dbo].[WriteNextPortionPersistedStream]
@DataPointer binary(16),
@DataIndex int,
@DeleteLength int,
@Content image
AS

UPDATETEXT [ReportServer$MXCATBDTempDB].dbo.PersistedStream.Content @DataPointer @DataIndex @DeleteLength @Content
go

