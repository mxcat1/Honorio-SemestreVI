
CREATE PROC [dbo].[TempChunkExists]
	@ChunkId uniqueidentifier
AS
BEGIN
	SELECT COUNT(1) FROM [ReportServer$MXCATBDTempDB].dbo.SegmentedChunk
	WHERE ChunkId = @ChunkId
END
go

